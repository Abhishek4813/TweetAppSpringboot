package com.tweetapp.Dao;

import java.util.List;

import com.tweetapp.Entity.UsersEntity;
import com.tweetapp.error.UserExistException;
import com.tweetapp.error.UserNotFoundException;
import com.tweetapp.pojo.ResponseUser;

public interface UserDao {

	ResponseUser addNewUser(UsersEntity user) throws UserExistException;
	UsersEntity findUser(String username) throws UserNotFoundException;
	ResponseUser updateUser(UsersEntity user) throws Exception;
	List<ResponseUser> getAllUsers() throws Exception;
	
}
