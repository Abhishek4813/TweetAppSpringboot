package com.tweetapp.Dao;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tweetapp.Entity.UsersEntity;
import com.tweetapp.pojo.ResponseUser;
import com.tweetapp.Repository.UserRepository;
import com.tweetapp.error.UserExistException;
import com.tweetapp.error.UserNotFoundException;

@Repository
public class UserDaoImpl implements UserDao{

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	private static final Logger log = LoggerFactory.getLogger(UserDaoImpl.class);
	
	@Override
	public ResponseUser addNewUser(UsersEntity user) throws UserExistException {
		log.info("TweetApp | UserDaoImpl |add new user | username : "+user.getLoginId());
		ResponseUser responseUser= null;
		try {
			modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
			responseUser= modelMapper.map(userRepository.save(user), ResponseUser.class);
		}catch(Exception e) {
			log.info("TweetApp | UserDaoImpl |fail to add user | "+e);
			throw new UserExistException("User Exist");
		}
		return responseUser;
	}

	@Override
	public UsersEntity findUser(String username) throws UserNotFoundException {
		log.info("TweetApp | UserDaoImpl |find user by username | username : "+username);
		UsersEntity user = userRepository.findByLoginId(username);
		if(null != user)
			return user;
		log.info("TweetApp | UserDaoImpl |No user found | username : "+username);
		throw new UserNotFoundException("Unavailable");
	}

	@Override
	public ResponseUser updateUser(UsersEntity user) throws Exception{
		log.info("TweetApp | UserDaoImpl | update user | username : "+user.getLoginId());
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		ResponseUser responseUser= modelMapper.map(userRepository.save(user), ResponseUser.class);
		return responseUser;
	}

	@Override
	public List<ResponseUser> getAllUsers() throws Exception {
		log.info("TweetApp | UserDaoImpl | get all user");
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		List<ResponseUser> users = new ArrayList<>();
		userRepository.findAll().forEach(data->{
			ResponseUser user = modelMapper.map(data, ResponseUser.class);
			users.add(user);
		});
		return users;
	}
}
