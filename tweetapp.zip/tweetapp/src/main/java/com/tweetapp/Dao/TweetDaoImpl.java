package com.tweetapp.Dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Repository;

import com.tweetapp.Entity.ReplyEntity;
import com.tweetapp.Entity.TweetEntity;
import com.tweetapp.Repository.TweetRepository;
import com.tweetapp.pojo.KafkaTweetModel;
import com.tweetapp.service.TweetServiceImpl;

@Repository
public class TweetDaoImpl implements TweetDao{
	
	@Autowired
	private TweetRepository tweetRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	private static final Logger log = LoggerFactory.getLogger(TweetDaoImpl.class);

	@Override
	@KafkaListener(topics="Tweets", groupId="group-Json", containerFactory="concurrentKafkaListenerContainerFactory")
	public void postTweet(KafkaTweetModel tweet){
		
		log.info("TweetApp | TweetDaoImpl |Post Tweet | username : "+tweet.getUsername());
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		TweetEntity tweetDetail= modelMapper.map(tweet,TweetEntity.class);
		tweetDetail.setLikes(0);
		tweetDetail.setReply(new ArrayList<ReplyEntity>());
		tweetDetail.setLikeBy(new ArrayList<String>());
		tweetDetail.setTime(new Date());
		try {
		TweetEntity response = tweetRepository.save(tweetDetail);
		if(null == response) {
			log.info("TweetApp | TweetDaoImpl |Post Tweet | fail to save the user deetail : "+tweet.getUsername());
			throw new Exception("Fail to Consume Message");
		}
		}
		catch(Exception e) {
			log.info("TweetApp | TweetDaoImpl |Post Tweet | Error occured while publishing tweet on kafka : "+e);
		}
	}

	@Override
	public TweetEntity updateTweet(TweetEntity tweet) throws Exception {
		log.info("TweetApp | TweetDaoImpl | update tweet  | username : "+tweet.getUsername());
		return tweetRepository.save(tweet);
	}

	@Override
	public TweetEntity findTweet(String id) throws Exception {
		log.info("TweetApp | TweetDaoImpl | find tweet | id : "+id);
		return tweetRepository.findById(id).get();
	}

	@Override
	public void deleteTweet(String id) throws Exception {
		log.info("TweetApp | TweetDaoImpl | delete tweet | id : "+id);
		tweetRepository.deleteById(id);
	}

	@Override
	public List<TweetEntity> getAllTweets() throws Exception {
		log.info("TweetApp | TweetDaoImpl | get all tweets");
		List<TweetEntity> tweets = new ArrayList<>();
		tweetRepository.findAll().forEach(data->{
			tweets.add(data);
		});
		return tweets;
	}

	@Override
	public List<TweetEntity> getAllTweetsByUsername(String username) throws Exception {
		log.info("TweetApp | TweetDaoImpl | get all tweets by username | username : "+username);
		List<TweetEntity> tweets = new ArrayList<>();
		tweetRepository.findByUsername(username).forEach(data->{
			tweets.add(data);
		});
		return tweets;
	}
}
