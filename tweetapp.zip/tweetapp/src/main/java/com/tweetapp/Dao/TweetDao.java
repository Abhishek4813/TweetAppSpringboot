package com.tweetapp.Dao;

import java.util.List;

import com.tweetapp.Entity.TweetEntity;
import com.tweetapp.pojo.KafkaTweetModel;

public interface TweetDao {
	
	void postTweet(KafkaTweetModel tweet);
	TweetEntity updateTweet(TweetEntity tweet) throws Exception;
	TweetEntity findTweet(String id) throws Exception;
	void deleteTweet(String id) throws Exception;
	List<TweetEntity> getAllTweets() throws Exception;
	List<TweetEntity> getAllTweetsByUsername(String usernames) throws Exception;
}
