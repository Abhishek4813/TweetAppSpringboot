package com.tweetapp.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.Entity.UsersEntity;

@Repository
public interface UserRepository extends MongoRepository<UsersEntity,String>{
	
	UsersEntity findByLoginId(String loginId);

}
