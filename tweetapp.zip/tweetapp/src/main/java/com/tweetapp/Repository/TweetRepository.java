package com.tweetapp.Repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.Entity.TweetEntity;

@Repository
public interface TweetRepository extends MongoRepository<TweetEntity,String>{

	List<TweetEntity> findByUsername(String username);
}
