package com.tweetapp.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.Entity.TweetEntity;
import com.tweetapp.error.AlreadyLikedException;
import com.tweetapp.error.EditNotAllowedException;
import com.tweetapp.error.MethodArgumentException;
import com.tweetapp.pojo.TweetModel;
import com.tweetapp.service.TweetService;

@RestController
@CrossOrigin
@RequestMapping("/api/v1.0/tweets")
public class TweetController {
	
	private static final Logger log = LoggerFactory.getLogger(TweetController.class);
	
	@Autowired
	private TweetService tweetServiceImpl;

	@PostMapping("/{username}/add")
	public ResponseEntity<Map<String, String>> postNewTweet(@PathVariable("username") String username, @Valid @RequestBody TweetModel tweet, BindingResult failure) 
			throws Exception,MethodArgumentException{
		log.info("TweetApp | TweetController |post new tweets | username "+username);
		if(failure.hasErrors()) {
			log.info("TweetApp | TweetController | request data validation fail | username "+username);
			throw new MethodArgumentException(failure.getFieldError().getDefaultMessage());
		}
		Map<String, String> result = new HashMap<>();
		String responseMsg = tweetServiceImpl.postTweet(tweet,username);
		result.put("Status", responseMsg);
		
		return ResponseEntity.status(HttpStatus.OK).body(result);
	}
	
	@PutMapping("/{username}/update/{id}")
	public ResponseEntity<TweetEntity> updateTweet(@PathVariable("username") String username, @PathVariable("id") String id,
			@Valid @RequestBody TweetModel tweet, BindingResult failure) throws Exception, EditNotAllowedException,MethodArgumentException{
		log.info("TweetApp | TweetController | update tweet  | username "+username);
		if(failure.hasErrors()) {
			log.info("TweetApp | TweetController | request data validation fail | username "+username);
			throw new MethodArgumentException(failure.getFieldError().getDefaultMessage());
		}
		return ResponseEntity.status(HttpStatus.OK).body(tweetServiceImpl.updateTweet(tweet,username,id));
	}
	
	@DeleteMapping("/{username}/delete/{id}")
	public ResponseEntity<Map<String,String>> deleteTweet(@PathVariable("username") String username, @PathVariable("id") String id)
			throws Exception, EditNotAllowedException{
		log.info("TweetApp | TweetController | delete tweet  | id "+id);
		tweetServiceImpl.deleteTweet(id, username);
		Map<String ,String> response = new HashMap<>();
		response.put("status", "success");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	
	@PostMapping("/{username}/reply/{id}")
	public ResponseEntity<TweetEntity> replyOnTweet(@PathVariable("username") String username, @PathVariable("id") String id,
			@Valid @RequestBody TweetModel tweet, BindingResult failure) throws Exception{
		log.info("TweetApp | TweetController | reply to tweet  | id "+id);
		if(failure.hasErrors()) {
			log.info("TweetApp | TweetController | request data validation fail  | username "+username);
			throw new MethodArgumentException(failure.getFieldError().getDefaultMessage());
		}
		return ResponseEntity.status(HttpStatus.OK).body(tweetServiceImpl.replyTweet(tweet, username, id));
	}
	
	@PutMapping("/{username}/like/{id}")
	public ResponseEntity<TweetEntity> likeTweet(@PathVariable("username") String username, @PathVariable("id") String id)
			throws Exception, AlreadyLikedException{
		log.info("TweetApp | TweetController | like tweet  | id "+id);
		return ResponseEntity.status(HttpStatus.OK).body(tweetServiceImpl.likeTweet(username, id));
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<TweetEntity>> getAllTweet()
			throws Exception{	
		log.info("TweetApp | TweetController | get all tweets");
		return ResponseEntity.status(HttpStatus.OK).body(tweetServiceImpl.getAllTweets());
	}
	
	@GetMapping("/{username}")
	public ResponseEntity<List<TweetEntity>> getAllTweetOfUser(@PathVariable("username") String username)
			throws Exception{
		log.info("TweetApp | TweetController | get all tweets by username | username : "+ username);
		return ResponseEntity.status(HttpStatus.OK).body(tweetServiceImpl.getAllTweetsByUsername(username));
	}
}
