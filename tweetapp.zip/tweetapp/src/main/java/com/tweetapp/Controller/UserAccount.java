package com.tweetapp.Controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.Entity.UsersEntity;
import com.tweetapp.error.LoginFailedException;
import com.tweetapp.error.MethodArgumentException;
import com.tweetapp.error.PasswordMisMatchException;
import com.tweetapp.error.UserExistException;
import com.tweetapp.error.UserNotFoundException;
import com.tweetapp.pojo.RequestUser;
import com.tweetapp.pojo.ResetPassword;
import com.tweetapp.pojo.ResponseUser;
import com.tweetapp.pojo.UserLogin;
import com.tweetapp.service.UserLoginService;
import com.tweetapp.service.UserService;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
@CrossOrigin
@RequestMapping("/api/v1.0/tweets")
public class UserAccount {
	
	@Autowired
	private UserService userServiceImpl;
	
	@Autowired
	private UserLoginService userLoginService;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	private static final Logger log = LoggerFactory.getLogger(UserAccount .class);

	@PostMapping("/register")
	public ResponseEntity<ResponseUser> registerNewUSer(@Valid @RequestBody RequestUser user, BindingResult result) 
			throws PasswordMisMatchException, UserExistException, MethodArgumentException{
		log.info("TweetApp | UserAccount | regeister new user | username "+user.getLoginId());
		if(result.hasErrors()) {
			log.info("TweetApp | UserAccount | request data validation fail | username "+user.getLoginId());
			throw new MethodArgumentException(result.getFieldError().getDefaultMessage());
		}
		return ResponseEntity.status(HttpStatus.OK).body(userServiceImpl.addNewUSer(user));
	}
	
	@GetMapping("/login")
	public ResponseEntity<Map<String,String>> signInUser(@Valid @RequestBody UserLogin credential, BindingResult result) 
			throws LoginFailedException, MethodArgumentException{
		log.info("TweetApp | UserAccount | sign in by user | username "+credential.getUsername());
		if(result.hasErrors()) {
			log.info("TweetApp | UserAccount | request data validation fail | username "+credential.getUsername());
			throw new MethodArgumentException(result.getFieldError().getDefaultMessage());
		}
		Map<String,String> authToken = new HashMap<>();
		UserDetails user= userLoginService.loadUserByUsername(credential.getUsername());
		if(null != user && passwordEncoder.matches(credential.getPassword(), user.getPassword())) {
		authToken.put("token",generateToken(user.getUsername()));
		return ResponseEntity.status(HttpStatus.OK).body(authToken);
		}
		log.info("TweetApp | UserAccount | failed to logged in check password | username : "+credential.getUsername());
		throw new LoginFailedException("Invalid");
	}
	
	@GetMapping("/{username}/forgot")
	public ResponseEntity<Map<String,String>> resetPassword(@PathVariable("username") String username, @Valid @RequestBody ResetPassword data, BindingResult failure)
	throws UserNotFoundException, PasswordMisMatchException, Exception{
		log.info("TweetApp | UserAccount | Reset password | username "+username);
		if(failure.hasErrors()) {
			log.info("TweetApp | UserAccount | request data validation fail | username "+username);
			throw new MethodArgumentException(failure.getFieldError().getDefaultMessage());
		}
		UsersEntity user = userServiceImpl.findUser(username);
		if(data.getNewPassword().equals(data.getConfirmPassword()) && passwordEncoder.matches(data.getOldPassword(), user.getPassword())) {
			user.setPassword(passwordEncoder.encode(data.getNewPassword()));
			userServiceImpl.updateUser(user);
			Map<String, String> result = new HashMap<>();
			result.put("Reset", "success");
			return ResponseEntity.status(HttpStatus.OK).body(result);
		}
		log.info("TweetApp | UserAccount | password mismatch check confirm password | username "+username);
		throw new PasswordMisMatchException("Invalid Password");
	}
	
	@GetMapping("/users/all")
	public ResponseEntity<List<ResponseUser>> getAllUsers() throws Exception{
		log.info("TweetApp | UserAccount | get all users");
		return ResponseEntity.status(HttpStatus.OK).body(userServiceImpl.getAllUsers());
	}
	
	private String generateToken(String user) {
		log.info("TweetApp | UserAccount | generating JWT token | username :"+user);
		String token= null;
		JwtBuilder builder = Jwts.builder();
		builder.setSubject(user);
		builder.setIssuedAt(new Date());
		builder.setExpiration(new Date(new Date().getTime()+(30*60*1000)));
		builder.signWith(SignatureAlgorithm.HS256, "tweetAppKey");
		token= builder.compact();
		return token;
	}
	
}
