package com.tweetapp.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.tweetapp.Dao.UserDaoImpl;
import com.tweetapp.error.EditNotAllowedException;
import com.tweetapp.error.LoginFailedException;
import com.tweetapp.error.MethodArgumentException;
import com.tweetapp.error.PasswordMisMatchException;
import com.tweetapp.error.UserExistException;
import com.tweetapp.pojo.ErrorModel;

@ControllerAdvice
public class ErrorController {
	
	private static final Logger log = LoggerFactory.getLogger(ErrorController.class);
	
	@ExceptionHandler
	public ResponseEntity<ErrorModel> handelException(Exception e) {
		log.info("TweetApp | ErrorController |Generic Exception | "+e);
		ErrorModel error = new ErrorModel();
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		error.setErrorlog(e.toString());
		error.setErrorMsg(e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(error);
	}
	
	@ExceptionHandler
	public ResponseEntity<ErrorModel> handelUserExistException(UserExistException e) {
		log.info("TweetApp | ErrorController |User already exist | "+e);
		ErrorModel error = new ErrorModel();
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		error.setErrorlog(e.toString());
		error.setErrorMsg(e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(error);
	}
	
	@ExceptionHandler
	public ResponseEntity<ErrorModel> handelMethodArgumentNotValidException(MethodArgumentNotValidException e) {
		log.info("TweetApp | ErrorController |Method argument not valid | "+e);
		ErrorModel error = new ErrorModel();
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		error.setErrorlog(e.toString());
		error.setErrorMsg(e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(error);
	}
	
	@ExceptionHandler
	public ResponseEntity<ErrorModel> handelPasswordMisMatchException(PasswordMisMatchException e) {
		log.info("TweetApp | ErrorController | password comparison failed | "+e);
		ErrorModel error = new ErrorModel();
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		error.setErrorlog(e.toString());
		error.setErrorMsg(e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(error);
	}
	
	@ExceptionHandler
	public ResponseEntity<ErrorModel> handelLoginFailedException(LoginFailedException e) {
		log.info("TweetApp | ErrorController | user login fail | "+e);
		ErrorModel error = new ErrorModel();
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		error.setErrorlog(e.toString());
		error.setErrorMsg(e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(error);
	}
	
	@ExceptionHandler
	public ResponseEntity<ErrorModel> handelEditNotAllowedException(EditNotAllowedException e) {
		log.info("TweetApp | ErrorController | you are not allowed to edit tweets | "+e);
		ErrorModel error = new ErrorModel();
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		error.setErrorlog(e.toString());
		error.setErrorMsg(e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(error);
	}
	
	@ExceptionHandler
	public ResponseEntity<ErrorModel> handelEditNotAllowedException(MethodArgumentException e) {
		log.info("TweetApp | ErrorController | you are not allowed to edit tweets | "+e);
		ErrorModel error = new ErrorModel();
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		error.setErrorlog(e.toString());
		error.setErrorMsg(e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(error);
	}
}
