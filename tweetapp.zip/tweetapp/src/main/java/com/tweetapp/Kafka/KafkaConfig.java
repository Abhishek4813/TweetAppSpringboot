package com.tweetapp.Kafka;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import com.tweetapp.pojo.KafkaTweetModel;

@Configuration
public class KafkaConfig {
	
	private static final Logger log = LoggerFactory.getLogger(KafkaConfig.class);
	
	@Bean
	ProducerFactory<String,KafkaTweetModel> producerFactory(){
		log.info("TweetApp | KafkaConfig |kafka Producer Configuration");
		
		Map<String, Object> config = new HashMap<>();
		config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "z-3.mytweetappmks.y0hj2n.c19.kafka.us-east-1.amazonaws.com:2181,z-2.mytweetappmks.y0hj2n.c19.kafka.us-east-1.amazonaws.com:2181,z-1.mytweetappmks.y0hj2n.c19.kafka.us-east-1.amazonaws.com:2181");
		config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
		return new DefaultKafkaProducerFactory<>(config);
	}
	
	@Bean
	KafkaTemplate<String, KafkaTweetModel> kafkaTemplate(){
		log.info("TweetApp | KafkaConfig |Kafka Producer Configuration");
		return new KafkaTemplate<>(producerFactory());
	}

}
