package com.tweetapp.Kafka;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import com.tweetapp.pojo.KafkaTweetModel;

@EnableKafka
@Configuration
public class KafkaConsumerConfig {
	
	private static final Logger log = LoggerFactory.getLogger(KafkaConsumerConfig.class);

	@Bean
	ConsumerFactory<String, KafkaTweetModel> consumerFactory(){
		log.info("TweetApp | KafkaConsumerConfig |kafka consumer configuration");
		Map<String, Object> config = new HashMap<>();
		config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "z-3.mytweetappmks.y0hj2n.c19.kafka.us-east-1.amazonaws.com:2181,z-2.mytweetappmks.y0hj2n.c19.kafka.us-east-1.amazonaws.com:2181,z-1.mytweetappmks.y0hj2n.c19.kafka.us-east-1.amazonaws.com:2181");
		config.put(ConsumerConfig.GROUP_ID_CONFIG, "group-Json");
		config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,JsonDeserializer.class);
		config.put(JsonDeserializer.TRUSTED_PACKAGES, "*");
		return new DefaultKafkaConsumerFactory<>(config);
	}
	
	@Bean
	ConcurrentKafkaListenerContainerFactory<String, KafkaTweetModel> concurrentKafkaListenerContainerFactory(){
		log.info("TweetApp | KafkaConsumerConfig |kafka consumer Bean");
		ConcurrentKafkaListenerContainerFactory<String, KafkaTweetModel> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactory());
		return factory;
	}
}
