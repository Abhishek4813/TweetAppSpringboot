package com.tweetapp.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.tweetapp.service.UserLoginService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;

@Component
public class JWTAuthorizationFilter extends OncePerRequestFilter{

	@Autowired
	private UserLoginService userLoginService;
	
	private static final Logger log = LoggerFactory.getLogger(JWTAuthorizationFilter.class);
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		log.info("TweetApp | JWTAuthorizationFilter |JTW Authorization filter");
		
		String header = request.getHeader("Authorization");
		if(null == header || ! header.startsWith("Bearer ")) {
			log.info("TweetApp | JWTAuthorizationFilter | NO Token Passed");
			filterChain.doFilter(request, response);
			return;
		}
		UsernamePasswordAuthenticationToken authenticate = getAuthentication(request);
		SecurityContextHolder.getContext().setAuthentication(authenticate);
		filterChain.doFilter(request, response);
		
	}
	
	private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {
		log.info("TweetApp | JWTAuthorizationFilter |Authorizing Username and password.");
		String token = request.getHeader("Authorization");
		if(null != token) {
			Jws<Claims> jws;
			try {
				jws= Jwts.parser().setSigningKey("tweetAppKey").parseClaimsJws(token.replace("Bearer ", ""));
				String user= jws.getBody().getSubject();
				if(null != user) {
					log.info("TweetApp | JWTAuthorizationFilter | authorizing user | username : "+user);
					UserDetails userDetail= userLoginService.loadUserByUsername(user);
					return new UsernamePasswordAuthenticationToken(userDetail.getUsername(),null, userDetail.getAuthorities());
				}
			}catch(JwtException e) {
					log.info("TweetApp | JWTAuthorizationFilter | Error occured while parsing token");
					return null;
				}
			return null;
		}
		log.info("TweetApp | JWTAuthorizationFilter | NO Token Passed");
		return null;
	}
}