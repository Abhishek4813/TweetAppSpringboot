package com.tweetapp.security;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@EnableWebSecurity
@Configuration
public class SecurityConfig{
	
	@Autowired
	private JWTAuthorizationFilter jWTAuthorizationFilter;
	
	private static final Logger log = LoggerFactory.getLogger(SecurityConfig.class);

	@Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
		log.info("TweetApp | SecurityConfig |Authentication Manager Bean Created");
        return authenticationConfiguration.getAuthenticationManager();
    }
    
	@Bean
    PasswordEncoder passwordEncoder() {
		log.info("TweetApp | SecurityConfig | password Encoder bean created");
        return new BCryptPasswordEncoder();
	}
	
	@Bean
	ModelMapper modelMapper() {
		log.info("TweetApp | SecurityConfig | ModelMapper bean created");
		return new ModelMapper();
	}
	
	@Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		log.info("TweetApp | SecurityConfig | SecurityFilterChain bean created");
        http.csrf().disable().httpBasic().and().authorizeRequests()
        .antMatchers("/api/v1.0/tweets/register").permitAll()
        .antMatchers("/api/v1.0/tweets/login").permitAll()
        .antMatchers("/**").hasRole("USER");
       http.addFilterBefore(jWTAuthorizationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
