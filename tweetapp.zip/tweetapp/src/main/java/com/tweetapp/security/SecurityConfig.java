package com.tweetapp.security;

import java.util.Arrays;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@EnableWebSecurity
@Configuration
public class SecurityConfig{
	
	@Autowired
	private JWTAuthorizationFilter jWTAuthorizationFilter;
	
	private static final Logger log = LoggerFactory.getLogger(SecurityConfig.class);

	@Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
		log.info("TweetApp | SecurityConfig |Authentication Manager Bean Created");
        return authenticationConfiguration.getAuthenticationManager();
    }
    
	@Bean
    PasswordEncoder passwordEncoder() {
		log.info("TweetApp | SecurityConfig | password Encoder bean created");
        return new BCryptPasswordEncoder();
	}
	
	@Bean
	ModelMapper modelMapper() {
		log.info("TweetApp | SecurityConfig | ModelMapper bean created");
		return new ModelMapper();
	}
	
	@Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		log.info("TweetApp | SecurityConfig | SecurityFilterChain bean created");
		http.cors().configurationSource(new  CorsConfigurationSource() {
			@Override
			public CorsConfiguration getCorsConfiguration(HttpServletRequest request) {
				CorsConfiguration configuration = new CorsConfiguration();
				configuration.setAllowedOrigins(Collections.singletonList("http://localhost:3000"));
				configuration.setAllowedMethods(Collections.singletonList("*"));
				configuration.setAllowCredentials(true);
				configuration.setAllowedHeaders(Collections.singletonList("*"));
				configuration.setMaxAge(3600L);
				return configuration;
			}
		}).and().csrf().disable().httpBasic().and().authorizeRequests()
		.antMatchers("/api/v1.0/tweets/login").permitAll()
		.antMatchers("/api/v1.0/tweets/register").permitAll()
		.antMatchers("/**").hasRole("USER");
        
        
       http.addFilterBefore(jWTAuthorizationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
