package com.tweetapp.Entity;


import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document(collection="users")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UsersEntity {
	@Id
	@GeneratedValue
	String id;
	private String firstName;
	private String lastName;
	@Indexed(unique=true)
	private String email;
	@Indexed(unique=true)
	private String loginId;
	private String password;
	private String contactNumber;
}
