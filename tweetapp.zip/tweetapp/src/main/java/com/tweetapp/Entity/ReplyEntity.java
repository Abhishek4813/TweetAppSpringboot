package com.tweetapp.Entity;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReplyEntity {
	
	private String userId;
	private String description;
	private Date time;
	private String tags;
}
