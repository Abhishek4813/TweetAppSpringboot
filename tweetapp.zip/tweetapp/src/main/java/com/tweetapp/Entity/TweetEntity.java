package com.tweetapp.Entity;

import java.util.Date;
import java.util.List;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document(collection="Tweets")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TweetEntity {
	@Id
	@GeneratedValue
	private String id;
	private String username;
	private String description;
	private String tags;
	private Date time;
	private Integer likes;
	private List<String> likeBy;
	private List<ReplyEntity> reply;
}
