package com.tweetapp.error;

public class MethodArgumentException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public MethodArgumentException(String msg) {
		super(msg);
	}

}
