package com.tweetapp.error;

public class EditNotAllowedException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public EditNotAllowedException(String msg) {
		super(msg);
	}

}
