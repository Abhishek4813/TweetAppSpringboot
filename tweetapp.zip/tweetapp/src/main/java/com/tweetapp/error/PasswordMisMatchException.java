package com.tweetapp.error;

public class PasswordMisMatchException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public PasswordMisMatchException(String msg){
		super(msg);
	}
	

}
