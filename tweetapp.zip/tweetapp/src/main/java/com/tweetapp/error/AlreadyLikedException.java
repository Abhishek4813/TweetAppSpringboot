package com.tweetapp.error;

public class AlreadyLikedException  extends Exception{

	private static final long serialVersionUID = 1L;

	public AlreadyLikedException(String msg){
		super(msg);
	}
}
