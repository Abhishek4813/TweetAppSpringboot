package com.tweetapp.pojo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TweetModel {
	@NotBlank(message="Add your thoughts to post")
	@Size(max=144, message="Tweet Should be less then 144 Character")
	String description;
	@Size(max=50, message="Tags Should be less then 50 Character")
	String tags;
}
