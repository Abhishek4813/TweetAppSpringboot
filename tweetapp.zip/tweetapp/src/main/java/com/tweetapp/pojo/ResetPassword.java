package com.tweetapp.pojo;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResetPassword {

	@NotBlank(message="Old Password is Required")
	private String oldPassword;
	@NotBlank(message="New Password is Required")
	private String newPassword;
	@NotBlank(message="Confirm Password is Required")
	private String confirmPassword;
}
