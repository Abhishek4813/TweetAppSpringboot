package com.tweetapp.pojo;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestUser {
	
	@NotBlank(message="First name is Required")
	private String firstName;
	@NotBlank(message="Last name is Required")
	private String lastName;
	@NotBlank(message="Email is Required")
	@Email(message="Email format is wrong")
	private String email;
	@NotBlank(message="LoginId is Required")
	private String loginId;
	@NotBlank(message="Password is Required")
	private String password;
	@NotBlank(message="confirmPassword is Required")
	private String confirmPassword;
	@NotBlank(message="Contact Number is Required")
	private String contactNumber;
}
