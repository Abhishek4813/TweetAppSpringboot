package com.tweetapp.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorModel {

	private String errorMsg;
	private Integer errorCode;
	private String errorlog;
}
