package com.tweetapp.service;

import java.util.Date;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.Dao.TweetDao;
import com.tweetapp.Entity.ReplyEntity;
import com.tweetapp.Entity.TweetEntity;
import com.tweetapp.error.AlreadyLikedException;
import com.tweetapp.error.EditNotAllowedException;
import com.tweetapp.pojo.KafkaTweetModel;
import com.tweetapp.pojo.TweetModel;
import org.springframework.kafka.core.KafkaTemplate;

@Service
public class TweetServiceImpl implements TweetService{

	@Autowired
	private TweetDao tweetDaoImpl;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private KafkaTemplate<String,KafkaTweetModel> kafkaTemplate;
	
	private static final Logger log = LoggerFactory.getLogger(TweetServiceImpl.class);
	
	@Override
	public String postTweet(TweetModel tweet, String username) throws Exception {
		log.info("TweetApp | TweetServiceImpl |Post Tweet | username : "+username);
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		KafkaTweetModel tweetDetail= modelMapper.map(tweet,KafkaTweetModel.class);
		tweetDetail.setUsername(username);
		kafkaTemplate.send("Tweets",tweetDetail);
		return "Tweet Published";
	}

	@Override
	public TweetEntity updateTweet(TweetModel tweet, String username, String id)
			throws Exception, EditNotAllowedException {
			log.info("TweetApp | TweetServiceImpl | update tweet | Id : "+id);
			TweetEntity tweetDetail = tweetDaoImpl.findTweet(id);
			if(null != tweetDetail && tweetDetail.getUsername().equals(username)) {
				tweetDetail.setDescription(tweet.getDescription());
				tweetDetail.setTags(tweet.getTags());
				return tweetDaoImpl.updateTweet(tweetDetail);
			}
			log.info("TweetApp | TweetServiceImpl | you are not owner of tweet | Id : "+id +" | username: "+username);
			throw new EditNotAllowedException("Not your tweet");
	}

	@Override
	public void deleteTweet(String id, String username) throws EditNotAllowedException, Exception {
		log.info("TweetApp | TweetServiceImpl | delete tweet | Id : "+id);
		TweetEntity tweetDetail = tweetDaoImpl.findTweet(id);
		if(null != tweetDetail && tweetDetail.getUsername().equals(username)) {
			tweetDaoImpl.deleteTweet(id);
			return;
		}
		log.info("TweetApp | TweetServiceImpl | you are not owner of tweet | Id : "+id +" | username: "+username);
		throw new EditNotAllowedException("Not your tweet");
	}

	@Override
	public TweetEntity replyTweet(TweetModel tweet, String username, String id) throws Exception {
		log.info("TweetApp | TweetServiceImpl | reply on tweet | Id : "+id +" | By Username : "+username);
		TweetEntity tweetDetail = tweetDaoImpl.findTweet(id);
		ReplyEntity reply = new ReplyEntity();
		reply.setDescription(tweet.getDescription());
		reply.setTags(tweet.getTags());
		reply.setUserId(username);
		reply.setTime(new Date());
		if(null != tweetDetail.getReply())
			tweetDetail.getReply().add(reply);
		return tweetDaoImpl.updateTweet(tweetDetail);
			
	}

	@Override
	public TweetEntity likeTweet(String username, String id) throws Exception, AlreadyLikedException {
		log.info("TweetApp | TweetServiceImpl | like on tweet | Id : "+id +" | By Username : "+username);
		TweetEntity tweetDetail = tweetDaoImpl.findTweet(id);
		if(null != tweetDetail.getLikeBy() && (tweetDetail.getLikeBy().isEmpty() || (! tweetDetail.getLikeBy().isEmpty() && ! tweetDetail.getLikeBy().contains(username)))) {
			tweetDetail.getLikeBy().add(username);
			tweetDetail.setLikes(tweetDetail.getLikes()+1);
			return tweetDaoImpl.updateTweet(tweetDetail);
		}
		throw new AlreadyLikedException("Post is already Liked by you");
	}

	@Override
	public List<TweetEntity> getAllTweets() throws Exception {
		log.info("TweetApp | TweetServiceImpl | Get All tweets");
		return tweetDaoImpl.getAllTweets();
	}

	@Override
	public List<TweetEntity> getAllTweetsByUsername(String username) throws Exception {
		log.info("TweetApp | TweetServiceImpl | Get All tweets by username | username : "+username);
		return tweetDaoImpl.getAllTweetsByUsername(username);
	}
}
