package com.tweetapp.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import com.tweetapp.Entity.UsersEntity;
import com.tweetapp.Repository.UserRepository;
import com.tweetapp.pojo.UserDetail;

@Service
public class UserLoginService implements UserDetailsService {
	
	@Autowired
	private UserRepository userRepository;
	
	private static final Logger log = LoggerFactory.getLogger(UserLoginService.class);

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		log.info("TweetApp | UserLoginService | load user by username | usernae : "+username);
		UsersEntity user = userRepository.findByLoginId(username);
		if(null != user) {	
			UserDetails userDetail = new UserDetail(user);
			return userDetail;
		}
		log.info("TweetApp | UserLoginService | No user available in database | usernae : "+username);
		throw new UsernameNotFoundException("Unavailable");
	}

}
