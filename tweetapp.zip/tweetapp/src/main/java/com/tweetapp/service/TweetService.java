package com.tweetapp.service;

import java.util.List;

import com.tweetapp.Entity.TweetEntity;
import com.tweetapp.error.EditNotAllowedException;
import com.tweetapp.error.AlreadyLikedException;
import com.tweetapp.pojo.TweetModel;

public interface TweetService {
	
	String postTweet(TweetModel tweet, String username) throws Exception;
	
	TweetEntity updateTweet(TweetModel tweet, String username, String id) throws Exception, EditNotAllowedException;
	
	void deleteTweet(String id, String username) throws EditNotAllowedException, Exception;
	
	TweetEntity replyTweet(TweetModel tweet, String username, String id) throws Exception;
	
	TweetEntity likeTweet(String username, String id) throws Exception, AlreadyLikedException;
	
	List<TweetEntity> getAllTweets() throws Exception;
	
	List<TweetEntity> getAllTweetsByUsername(String username) throws Exception;
}
