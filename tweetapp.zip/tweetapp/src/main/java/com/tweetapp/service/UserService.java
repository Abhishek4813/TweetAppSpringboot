package com.tweetapp.service;

import java.util.List;

import com.tweetapp.Entity.UsersEntity;
import com.tweetapp.error.PasswordMisMatchException;
import com.tweetapp.error.UserExistException;
import com.tweetapp.error.UserNotFoundException;
import com.tweetapp.pojo.RequestUser;
import com.tweetapp.pojo.ResponseUser;

public interface UserService  {

	ResponseUser addNewUSer(RequestUser user) throws PasswordMisMatchException, UserExistException;
	
	UsersEntity findUser(String username) throws UserNotFoundException;
	
	ResponseUser updateUser(UsersEntity user) throws Exception;
	
	List<ResponseUser> getAllUsers() throws Exception;
	
	

}
