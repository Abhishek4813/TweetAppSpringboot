package com.tweetapp.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.tweetapp.Dao.UserDao;
import com.tweetapp.Entity.UsersEntity;
import com.tweetapp.error.PasswordMisMatchException;
import com.tweetapp.error.UserExistException;
import com.tweetapp.error.UserNotFoundException;
import com.tweetapp.pojo.RequestUser;
import com.tweetapp.pojo.ResponseUser;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDaoImpl;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
	
	@Override
	public ResponseUser addNewUSer(RequestUser user) throws PasswordMisMatchException, UserExistException {
		log.info("TweetApp | USerServiceImpl | Add New User username : "+user.getLoginId());
		
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		if(user.getPassword().equals(user.getConfirmPassword())) {
			UsersEntity userEntity= modelMapper.map(user,UsersEntity.class);
			userEntity.setPassword(passwordEncoder.encode(userEntity.getPassword()));
			return userDaoImpl.addNewUser(userEntity);
		}
		log.info("TweetApp | USerServiceImpl | Password is not matchign with confirm password for username : "+user.getLoginId());
		throw new PasswordMisMatchException("Password MisMatch");			
	}

	@Override
	public UsersEntity findUser(String username) throws UserNotFoundException {
		log.info("TweetApp | USerServiceImpl | find user with username : "+username);
		return userDaoImpl.findUser(username);
	}

	@Override
	public ResponseUser updateUser(UsersEntity user) throws Exception {
		log.info("TweetApp | USerServiceImpl | update user | username : "+user.getLoginId());
		return userDaoImpl.updateUser(user);
	}

	@Override
	public List<ResponseUser> getAllUsers() throws Exception {
		log.info("TweetApp | USerServiceImpl | get all available users");
		return userDaoImpl.getAllUsers();
	}

}
