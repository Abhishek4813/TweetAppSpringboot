package com.tweetapp.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.modelmapper.config.Configuration;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;

import com.tweetapp.Dao.TweetDao;
import com.tweetapp.Entity.ReplyEntity;
import com.tweetapp.Entity.TweetEntity;
import com.tweetapp.pojo.KafkaTweetModel;
import com.tweetapp.pojo.TweetModel;

@SpringBootTest
public class TweetServiceImplTest {

	@Mock
	private TweetDao tweetDaoImpl;
	
	@Mock
	private ModelMapper modelMapper;
	
	@Mock
	private Configuration configuration;
	
	@Mock
	private KafkaTemplate<String, KafkaTweetModel> kafkaTemplate;
	
	@InjectMocks
	private TweetServiceImpl tweetServiceImpl = new TweetServiceImpl();
	
	@Test
	void testPostTweet() throws Exception {
		TweetModel tweetModel= new TweetModel();
		tweetModel.setDescription("Hello there this is my first Tweet");
		tweetModel.setTags("#FirstPost");
		
		KafkaTweetModel kafkaTweetModel = new KafkaTweetModel();
		kafkaTweetModel.setDescription("Hello there this is my first Tweet");
		kafkaTweetModel.setTags("#FirstPost");
		
		when(modelMapper.getConfiguration()).thenReturn(configuration);
		when(configuration.setMatchingStrategy(MatchingStrategies.STRICT)).thenReturn(configuration);
		when(modelMapper.map(tweetModel, KafkaTweetModel.class)).thenReturn(kafkaTweetModel);
		
		kafkaTemplate.send("Tweets",kafkaTweetModel);
		
		String result=tweetServiceImpl.postTweet(tweetModel, "abhi2");
		
		assertEquals(result,"Tweet Published");
		
	}
	
	@Test
	void testUpdateTweet() throws Exception {
		TweetModel tweetModel= new TweetModel();
		tweetModel.setDescription("Hello there this is my first Tweet");
		tweetModel.setTags("#FirstPost");
		
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(0);
		tweetResponse.setReply(new ArrayList<ReplyEntity>());
		tweetResponse.setLikeBy(new ArrayList<String>());
		
		when(tweetDaoImpl.findTweet("id0001")).thenReturn(tweetResponse);
		when(tweetDaoImpl.updateTweet(tweetResponse)).thenReturn(tweetResponse);
		TweetEntity result = tweetServiceImpl.updateTweet(tweetModel, "abhi2", "id0001");
		
		assertThat(result).usingRecursiveComparison().isEqualTo(tweetResponse);
		
	}
	
	@Test
	void testDeleteTweet() throws Exception {
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(0);
		tweetResponse.setReply(new ArrayList<ReplyEntity>());
		tweetResponse.setLikeBy(new ArrayList<String>());
		
		when(tweetDaoImpl.findTweet("id0001")).thenReturn(tweetResponse);
		tweetDaoImpl.deleteTweet("id0001");
		
		tweetServiceImpl.deleteTweet("id0001", "abhi2");
	}
	
	@Test
	void testReplyTweet() throws Exception {
		TweetModel tweetModel= new TweetModel();
		tweetModel.setDescription("My first Comment");
		tweetModel.setTags("#FirstComment");
		
		List<ReplyEntity> replyList = new ArrayList<ReplyEntity>();
		
		ReplyEntity reply = new ReplyEntity();
		reply.setDescription("My first Comment");
		reply.setTags("#FirstComment");
		reply.setUserId("abhi2");
		
		replyList.add(reply);
		
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(0);
		tweetResponse.setReply(replyList);
		tweetResponse.setLikeBy(new ArrayList<String>());
		
		TweetEntity tweetData = new TweetEntity();
		tweetData.setDescription("Hello there this is my first Tweet");
		tweetData.setTags("#FirstPost");
		tweetData.setUsername("abhi2");
		tweetData.setLikes(0);
		tweetData.setReply(new ArrayList<ReplyEntity>());
		tweetData.setLikeBy(new ArrayList<String>());
		
		when(tweetDaoImpl.findTweet("abhi0001")).thenReturn(tweetData);
		when(tweetDaoImpl.updateTweet(tweetResponse)).thenReturn(tweetResponse);
		TweetEntity result = tweetServiceImpl.replyTweet(tweetModel, "abhi2", "abhi0001");
		
		//assertThat(result).usingRecursiveComparison().isEqualTo(tweetResponse);
		
	}
	
	@Test
	void testLikeTweet() throws Exception {
		
		TweetEntity tweetData = new TweetEntity();
		tweetData.setDescription("Hello there this is my first Tweet");
		tweetData.setTags("#FirstPost");
		tweetData.setUsername("abhi2");
		tweetData.setLikes(0);
		tweetData.setReply(new ArrayList<ReplyEntity>());
		tweetData.setLikeBy(new ArrayList<String>());
		
		List<String> list = new ArrayList<>();
		list.add("abhi2");
		
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(1);
		tweetResponse.setReply(new ArrayList<ReplyEntity>());
		tweetResponse.setLikeBy(list);
		
		when(tweetDaoImpl.findTweet("abhi0001")).thenReturn(tweetData);
		when(tweetDaoImpl.updateTweet(tweetResponse)).thenReturn(tweetResponse);
		
		TweetEntity response = tweetServiceImpl.likeTweet("abhi2", "abhi0001");
		assertThat(response).usingRecursiveComparison().isEqualTo(tweetResponse);
	}
	
	@Test
	void testGetAllTweet() throws Exception {
		List<TweetEntity> tweetList = new ArrayList<>();
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(0);
		tweetResponse.setReply(new ArrayList<ReplyEntity>());
		tweetResponse.setLikeBy(new ArrayList<String>());
		
		when(tweetDaoImpl.getAllTweets()).thenReturn(tweetList);
		
		List<TweetEntity> result = tweetServiceImpl.getAllTweets();
		
		assertThat(result).usingRecursiveComparison().isEqualTo(tweetList);
	}
	
	@Test
	void testGetAllTweetByUsername() throws Exception {
		List<TweetEntity> tweetList = new ArrayList<>();
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(0);
		tweetResponse.setReply(new ArrayList<ReplyEntity>());
		tweetResponse.setLikeBy(new ArrayList<String>());
		
		when(tweetDaoImpl.getAllTweetsByUsername("abhi2")).thenReturn(tweetList);
		
		List<TweetEntity> result = tweetServiceImpl.getAllTweetsByUsername("abhi2");
		
		assertThat(result).usingRecursiveComparison().isEqualTo(tweetList);
	}
	
}
