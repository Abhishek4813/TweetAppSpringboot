package com.tweetapp.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.modelmapper.config.Configuration;
import org.modelmapper.convention.MatchingStrategies;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.tweetapp.Dao.UserDao;
import com.tweetapp.Entity.UsersEntity;
import com.tweetapp.error.PasswordMisMatchException;
import com.tweetapp.error.UserExistException;
import com.tweetapp.error.UserNotFoundException;
import com.tweetapp.pojo.RequestUser;
import com.tweetapp.pojo.ResponseUser;

@SpringBootTest
public class UserServiceImplTest {
	
	@Mock
	private UserDao userDaoImpl;
	
	@Mock
	private ModelMapper modelMapper;
	
	@Mock
	private Configuration configuration;
	
	@Mock
	private PasswordEncoder passwordEncoder;
	
	@InjectMocks
	private UserServiceImpl userServiceImpl = new UserServiceImpl();
	

	
	@Test
	void testAddNewUser() throws PasswordMisMatchException, UserExistException, UserNotFoundException {
		
		UsersEntity user= new UsersEntity();
		user.setFirstName("Abhishek");
		user.setLastName("Kumar");
		user.setEmail("abhishekkumar053@gmail.com");
		user.setLoginId("abhi2");
		user.setPassword("password");
		user.setContactNumber("9999999999");
		
		RequestUser requestUser= new RequestUser();
		requestUser.setFirstName("Abhishek");
		requestUser.setLastName("Kumar");
		requestUser.setEmail("abhishekkumar053@gmail.com");
		requestUser.setLoginId("abhi2");
		requestUser.setPassword("password");
		requestUser.setConfirmPassword("password");
		requestUser.setContactNumber("999999999");
		
		
		ResponseUser response= new ResponseUser();
		response.setFirstName("Abhishek");
		response.setLastName("Kumar");
		response.setEmail("abhishekkumar0539@gmail.com");
		response.setLoginId("abhi2");
		response.setContactNumber("9999999999");
		
		when(modelMapper.getConfiguration()).thenReturn(configuration);
		when(configuration.setMatchingStrategy(MatchingStrategies.STRICT)).thenReturn(configuration);
		when(modelMapper.map(requestUser, UsersEntity.class)).thenReturn(user);
		when(passwordEncoder.encode(user.getPassword())).thenReturn(user.getPassword());
		when(userDaoImpl.addNewUser(user)).thenReturn(response);
		
		ResponseUser result= userServiceImpl.addNewUSer(requestUser);
		
		assertThat(response).usingRecursiveComparison().isEqualTo(result);
	}
	
	
	@Test
	void testFindUser() throws UserNotFoundException {
		UsersEntity user= new UsersEntity();
		user.setFirstName("Abhishek");
		user.setLastName("Kumar");
		user.setEmail("abhishekkumar053@gmail.com");
		user.setLoginId("abhi2");
		user.setPassword("password");
		user.setContactNumber("9999999999");
		
		when(userDaoImpl.findUser("abhi2")).thenReturn(user);
		
		UsersEntity result= userServiceImpl.findUser("abhi2");
		
		assertThat(user).usingRecursiveComparison().isEqualTo(result);
		}
	
	@Test
	void testUpdateUser() throws Exception {
		UsersEntity user= new UsersEntity();
		user.setFirstName("Abhishek");
		user.setLastName("Kumar");
		user.setEmail("abhishekkumar053@gmail.com");
		user.setLoginId("abhi2");
		user.setPassword("password");
		user.setContactNumber("9999999999");
		
		ResponseUser response= new ResponseUser();
		response.setFirstName("Abhishek");
		response.setLastName("Kumar");
		response.setEmail("abhishekkumar0539@gmail.com");
		response.setLoginId("abhi2");
		response.setContactNumber("9999999999");
		
		when(userDaoImpl.updateUser(user)).thenReturn(response);
		
		ResponseUser result= userServiceImpl.updateUser(user);
		
		assertThat(response).usingRecursiveComparison().isEqualTo(result);
		}
	
	@Test
	void testGetAllUsers() throws Exception {
		List<ResponseUser> userList = new ArrayList<>(); 
		
		ResponseUser response= new ResponseUser();
		response.setFirstName("Abhishek");
		response.setLastName("Kumar");
		response.setEmail("abhishekkumar0539@gmail.com");
		response.setLoginId("abhi2");
		response.setContactNumber("9999999999");
		
		userList.add(response);
		
		when(userDaoImpl.getAllUsers()).thenReturn(userList);
		
		List<ResponseUser> result = userServiceImpl.getAllUsers();
		
		assertThat(userList).usingRecursiveComparison().isEqualTo(result);
	}

}
