package com.tweetapp.Controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.validation.BindingResult;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tweetapp.Entity.UsersEntity;
import com.tweetapp.pojo.RequestUser;
import com.tweetapp.pojo.ResetPassword;
import com.tweetapp.pojo.ResponseUser;
import com.tweetapp.pojo.UserDetail;
import com.tweetapp.pojo.UserLogin;
import com.tweetapp.service.UserLoginService;
import com.tweetapp.service.UserService;

@SpringBootTest
@AutoConfigureMockMvc
public class UserAccountTest {

	@Mock
	private UserService userServiceImpl;
	
	@Mock
	private UserLoginService userLoginService;
	
	@Mock
	private PasswordEncoder passwordEncoder;
	
	@Mock
	private BindingResult result;
	
	@Autowired
	private MockMvc mvc;
	
	@InjectMocks
	private UserAccount userAccount = new UserAccount();
	
	@Test
	void testRegisterNewUser() throws Exception {
		
		RequestUser requestUser= new RequestUser();
		requestUser.setFirstName("Abhishek");
		requestUser.setLastName("Kumar");
		requestUser.setEmail("abhishekkumar053@gmail.com");
		requestUser.setLoginId("abhi2");
		requestUser.setPassword("password");
		requestUser.setConfirmPassword("password");
		requestUser.setContactNumber("999999999");
		
		ObjectMapper dataMapper = new ObjectMapper();
		String data= dataMapper.writeValueAsString(requestUser);
		
		ResultActions actions = mvc.perform(post("/api/v1.0/tweets/register")
				.contentType(MediaType.APPLICATION_JSON)
				.content(data));
		
		actions.andExpect(status().isOk());
		actions.andReturn();
	}
	
	@Test
	void testSignInUser() throws Exception {
		UserLogin login = new UserLogin();
		login.setUsername("abhi2");
		login.setPassword("password");
		
		Map<String, String> response = new HashMap<>();
		response.put("token", "tokenhere");
		
		UsersEntity user= new UsersEntity();
		user.setFirstName("Abhishek");
		user.setLastName("Kumar");
		user.setEmail("abhishekkumar053@gmail.com");
		user.setLoginId("abhi2");
		user.setPassword("password");
		user.setContactNumber("9999999999");
		
		UserDetails userDetail = new UserDetail(user);
		
		when(userLoginService.loadUserByUsername("abhi2")).thenReturn(userDetail);
		when(passwordEncoder.matches(login.getPassword(), "password")).thenReturn(true);
		
		userAccount.signInUser(login.getUsername(), login.getPassword());
		
		ObjectMapper dataMapper = new ObjectMapper();
		String data= dataMapper.writeValueAsString(login);
		
		ResultActions actions = mvc.perform(get("/api/v1.0/tweets/login")
				.contentType(MediaType.APPLICATION_JSON)
				.content(data));
		
		actions.andExpect(status().isOk());
		actions.andReturn();
	}
	
	@Test
	void testForgotPassword() throws Exception {
		ResetPassword reset= new ResetPassword();
		reset.setOldPassword("password");
		reset.setNewPassword("pwd");
		reset.setConfirmPassword("pwd");
		
		Map<String, String> response = new HashMap<>();
		response.put("Reset", "Success");
		
		UsersEntity user= new UsersEntity();
		user.setFirstName("Abhishek");
		user.setLastName("Kumar");
		user.setEmail("abhishekkumar053@gmail.com");
		user.setLoginId("abhi2");
		user.setPassword("password");
		user.setContactNumber("9999999999");
		
		when(userServiceImpl.findUser("abhi2")).thenReturn(user);
		when(passwordEncoder.matches(user.getPassword(), "password")).thenReturn(true);
		when(passwordEncoder.encode("pwd")).thenReturn("IncodedPassword");
		
		userAccount.resetPassword("abhi2",reset ,result);
		
		ObjectMapper dataMapper = new ObjectMapper();
		String data= dataMapper.writeValueAsString(reset);
		
		ResultActions actions = mvc.perform(get("/api/v1.0/tweets/login")
				.contentType(MediaType.APPLICATION_JSON)
				.content(data));
		
		actions.andExpect(status().isOk());
		actions.andReturn();
	}
	
	@Test
	void testGetAllUser() throws Exception{
		
		List<ResponseUser> list = new ArrayList<>();
		
		ResponseUser response = new ResponseUser();
		response.setFirstName("Abhihek");
		response.setEmail("abhishekkumar0539@gmail.com");
		response.setLastName("kumar");
		response.setLoginId("abhi2");
		response.setContactNumber("9999999999");
		
		
		list.add(response);
		
		when(userServiceImpl.getAllUsers()).thenReturn(list);
		
		userAccount.getAllUsers();
		
		ResultActions actions = mvc.perform(get("/api/v1.0/tweets/login"));
		
		actions.andExpect(status().isOk());
		actions.andReturn();
		
		
	}
	
}
