package com.tweetapp.Dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.config.Configuration;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.boot.test.context.SpringBootTest;

import com.tweetapp.Entity.UsersEntity;
import com.tweetapp.Repository.UserRepository;
import com.tweetapp.error.UserExistException;
import com.tweetapp.error.UserNotFoundException;
import com.tweetapp.pojo.ResponseUser;

import org.modelmapper.ModelMapper;

@SpringBootTest
public class UserDaoImplTest {
	@Mock
	private UserRepository userRepository;
	
	@Mock
	private ModelMapper modelMapper;
	
	@Mock
	private Configuration configuration;
	
	@InjectMocks
	private UserDaoImpl userDaoImpl = new UserDaoImpl();
	
	@Test
	void testAddNewUser() throws UserExistException{
		UsersEntity user= new UsersEntity();
		user.setFirstName("Abhishek");
		user.setLastName("Kumar");
		user.setEmail("abhishekkumar0539@gmail.com");
		user.setLoginId("abhi2");
		user.setPassword("password");
		user.setContactNumber("9999999999");
		
		ResponseUser response= new ResponseUser();
		response.setFirstName("Abhishek");
		response.setLastName("Kumar");
		response.setEmail("abhishekkumar0539@gmail.com");
		response.setLoginId("abhi2");
		response.setContactNumber("9999999999");
		
		when(modelMapper.getConfiguration()).thenReturn(configuration);
		when(configuration.setMatchingStrategy(MatchingStrategies.STRICT)).thenReturn(configuration);
		when(modelMapper.map(user, ResponseUser.class)).thenReturn(response);
		
		when(userRepository.save(user)).thenReturn(user);
		
		ResponseUser result = userDaoImpl.addNewUser(user);
		
		assertThat(response).usingRecursiveComparison().isEqualTo(result);	
	}
	
	@Test 
	void testFindUser() throws UserNotFoundException {
		UsersEntity user= new UsersEntity();
		user.setFirstName("Abhishek");
		user.setLastName("Kumar");
		user.setEmail("abhishekkumar0539@gmail.com");
		user.setLoginId("abhi2");
		user.setPassword("password");
		user.setContactNumber("9999999999");
		
		when(userRepository.findByLoginId("abhi2")).thenReturn(user);
		
		UsersEntity result= userDaoImpl.findUser("abhi2");
		
		assertThat(user).usingRecursiveComparison().isEqualTo(result);
	}
	
	@Test
	void updateUser() throws Exception {
		UsersEntity user= new UsersEntity();
		user.setFirstName("Abhishek");
		user.setLastName("Kumar");
		user.setEmail("abhishekkumar0539@gmail.com");
		user.setLoginId("abhi2");
		user.setPassword("password");
		user.setContactNumber("9999999999");
		
		ResponseUser response= new ResponseUser();
		response.setFirstName("Abhishek");
		response.setLastName("Kumar");
		response.setEmail("abhishekkumar0539@gmail.com");
		response.setLoginId("abhi2");
		response.setContactNumber("9999999999");
		
		when(modelMapper.getConfiguration()).thenReturn(configuration);
		when(configuration.setMatchingStrategy(MatchingStrategies.STRICT)).thenReturn(configuration);
		when(modelMapper.map(user, ResponseUser.class)).thenReturn(response);
		when(userRepository.save(user)).thenReturn(user);
		
		ResponseUser result = userDaoImpl.updateUser(user);
		
		assertThat(response).usingRecursiveComparison().isEqualTo(result);
	}
	
	@Test
	void getAllUsers() throws Exception {
List<ResponseUser> userList = new ArrayList<>(); 
		
		ResponseUser response= new ResponseUser();
		response.setFirstName("Abhishek");
		response.setLastName("Kumar");
		response.setEmail("abhishekkumar0539@gmail.com");
		response.setLoginId("abhi2");
		response.setContactNumber("9999999999");
		
		userList.add(response);
		
		List<UsersEntity> responseEntity = new ArrayList<>(); 
		
		UsersEntity user= new UsersEntity();
		user.setFirstName("Abhishek");
		user.setLastName("Kumar");
		user.setEmail("abhishekkumar0539@gmail.com");
		user.setLoginId("abhi2");
		user.setPassword("password");
		user.setContactNumber("9999999999");
		
		responseEntity.add(user);
		
		when(modelMapper.getConfiguration()).thenReturn(configuration);
		when(configuration.setMatchingStrategy(MatchingStrategies.STRICT)).thenReturn(configuration);
		when(modelMapper.map(user, ResponseUser.class)).thenReturn(response);
		when(userRepository.findAll()).thenReturn(responseEntity);
		
		List<ResponseUser> result= userDaoImpl.getAllUsers();
		
		assertThat(result).usingRecursiveComparison().isEqualTo(userList);
	}
}
