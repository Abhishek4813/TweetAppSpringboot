package com.tweetapp.Dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.modelmapper.config.Configuration;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.boot.test.context.SpringBootTest;

import com.tweetapp.Entity.ReplyEntity;
import com.tweetapp.Entity.TweetEntity;
import com.tweetapp.Repository.TweetRepository;
import com.tweetapp.pojo.KafkaTweetModel;

@SpringBootTest
public class TweetDaoImplTest {
	
	@Mock
	private ModelMapper modelMapper;
	
	@Mock
	private TweetRepository tweetRepository;
	
	@Mock
	private Configuration configuration;
	
	@InjectMocks
	private TweetDaoImpl tweetDaoImpl = new TweetDaoImpl();
	
	

	@Test
	void testPostTweet() {
		
		KafkaTweetModel tweet= new KafkaTweetModel();
		tweet.setDescription("Hello there this is my first Tweet");
		tweet.setTags("#FirstPost");
		tweet.setUsername("abhi2");
		
		TweetEntity tweetEntity = new TweetEntity();
		tweetEntity.setDescription("Hello there this is my first Tweet");
		tweetEntity.setTags("#FirstPost");
		tweetEntity.setUsername("abhi2");
		
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(0);
		tweetResponse.setReply(new ArrayList<ReplyEntity>());
		tweetResponse.setLikeBy(new ArrayList<String>());
		
		
		when(modelMapper.getConfiguration()).thenReturn(configuration);
		when(configuration.setMatchingStrategy(MatchingStrategies.STRICT)).thenReturn(configuration);
		when(modelMapper.map(tweet, TweetEntity.class)).thenReturn(tweetEntity);
		when(tweetRepository.save(tweetResponse)).thenReturn(tweetResponse);
		
		tweetDaoImpl.postTweet(tweet);
	}
	
	@Test
	void testUpdateTweet() throws Exception {
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(0);
		tweetResponse.setReply(new ArrayList<ReplyEntity>());
		tweetResponse.setLikeBy(new ArrayList<String>());
		
		when(tweetRepository.save(tweetResponse)).thenReturn(tweetResponse);
		
		TweetEntity result = tweetDaoImpl.updateTweet(tweetResponse);
		
		assertThat(result).usingRecursiveComparison().isEqualTo(tweetResponse);
		
	}
	
	@Test
	void testFindTweet() throws Exception {
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(0);
		tweetResponse.setReply(new ArrayList<ReplyEntity>());
		tweetResponse.setLikeBy(new ArrayList<String>());
		
		Optional<TweetEntity> optionalTweet= Optional.of(tweetResponse);
		
		when(tweetRepository.findById("id0001")).thenReturn(optionalTweet);
		
		TweetEntity result = tweetDaoImpl.findTweet("id0001");
		
		assertThat(result).usingRecursiveComparison().isEqualTo(tweetResponse);
		
	}
	
	@Test
	void testDeleteTweet() throws Exception {
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(0);
		tweetResponse.setReply(new ArrayList<ReplyEntity>());
		tweetResponse.setLikeBy(new ArrayList<String>());
		
		tweetRepository.deleteById("id0001");
		
		tweetDaoImpl.deleteTweet("id0001");
	}
	
	@Test
	void testGetAllTweet() throws Exception {
		List<TweetEntity> tweetList = new ArrayList<>();
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(0);
		tweetResponse.setReply(new ArrayList<ReplyEntity>());
		tweetResponse.setLikeBy(new ArrayList<String>());
		
		when(tweetRepository.findAll()).thenReturn(tweetList);
		
		List<TweetEntity> result = tweetDaoImpl.getAllTweets();
		
		assertThat(result).usingRecursiveComparison().isEqualTo(tweetList);
	}
	
	@Test
	void testGetAllTweetByUsername() throws Exception {
		List<TweetEntity> tweetList = new ArrayList<>();
		TweetEntity tweetResponse = new TweetEntity();
		tweetResponse.setDescription("Hello there this is my first Tweet");
		tweetResponse.setTags("#FirstPost");
		tweetResponse.setUsername("abhi2");
		tweetResponse.setLikes(0);
		tweetResponse.setReply(new ArrayList<ReplyEntity>());
		tweetResponse.setLikeBy(new ArrayList<String>());
		
		when(tweetRepository.findByUsername("abhi2")).thenReturn(tweetList);
		
		List<TweetEntity> result = tweetDaoImpl.getAllTweetsByUsername("abhi2");
		
		assertThat(result).usingRecursiveComparison().isEqualTo(tweetList);
	}
	
}
